// PLATFORM COMPATIBILITY SHIM ONLY (deploy_game requires logic.js at zip root).
// Goblin Warren V1 is a fully client-side sandbox: all game rules live in
// game.js and run in the browser; nothing is server-authoritative and nothing
// here touches HELEN state. This module intentionally implements no rules.
module.exports = { name: "goblin-warren-v1", clientOnly: true,
  note: "shim ⊆ platform adaptation; not a game redesign; no hidden backend" };
