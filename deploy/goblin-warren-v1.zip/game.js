/* Goblin Warren — iPhone V1 — game.js
   PLAYABLE SANDBOX PROTOTYPE · AUTHORITY:false · CANON:false · SHIP:false
   localStorage local memory only — never called a receipt or ledger.
   Vanilla JS. No build step. No frameworks. No network calls.
*/
(function () {
"use strict";

var STORAGE_KEY = "goblin_warren_v1_state";
var STATE_VERSION = 1;

/* ---------------------------------------------------------------------
   WORLD DATA (visual language — unchanged by the state-contract update)
--------------------------------------------------------------------- */

var ZONES = [
  { id: "tree",    name: "Akashic Tree",   icon: "🌳", x: 50, y: 16, color: "#b98cff" },
  { id: "garden",  name: "Garden Plot",    icon: "🌸", x: 20, y: 40, color: "#6ee7a0" },
  { id: "nursery", name: "Bug Nursery",    icon: "🪲", x: 80, y: 40, color: "#e3ff6e" },
  { id: "forge",   name: "Receipt Forge",  icon: "🔥", x: 27, y: 72, color: "#ffb15c" },
  { id: "gate",    name: "Mycelial Gate",  icon: "🍄", x: 73, y: 72, color: "#c9a6ff" }
];
function zoneById(id) { for (var i = 0; i < ZONES.length; i++) if (ZONES[i].id === id) return ZONES[i]; return ZONES[0]; }
function zoneName(id) { return zoneById(id).name; }

var GOBLIN_DEFS = [
  { id: "lulu", name: "Lulu", role: "Detour Specialist", trait: "curious",   color: "#9be8c5", preference: "gate",    aversion: "forge",
    homeTask: "exploring" },
  { id: "pip",  name: "Pip",  role: "Archivist",          trait: "careful",   color: "#8bb26b", preference: "forge",   aversion: "nursery",
    homeTask: "archiving" },
  { id: "zaz",  name: "Zaz",  role: "Gardener",           trait: "warm",      color: "#55c77c", preference: "garden",  aversion: "gate",
    homeTask: "gardening" },
  { id: "nib",  name: "Nib",  role: "Forger",             trait: "restless",  color: "#a9c98a", preference: "nursery", aversion: "garden",
    homeTask: "tinkering" }
];

/* Lulu modes — ids are kebab-case per the state contract. */
var LULU_MODES = [
  { id: "bouffon-tendre",           name: "Bouffon Tendre",           icon: "🎭", accent: "#ff9ecb", voice: "Lulu grins, gentle and odd:" },
  { id: "punk-du-repos",            name: "Punk du Repos",            icon: "🛌", accent: "#ffb15c", voice: "Lulu slumps, unbothered:" },
  { id: "romantique-des-questions", name: "Romantique des Questions", icon: "❓", accent: "#c9b6ff", voice: "Lulu tilts her head, dreamy:" },
  { id: "gremlin-des-side-quests",  name: "Gremlin des Side Quests",  icon: "🗺️", accent: "#6ee7a0", voice: "Lulu already has a map out:" },
  { id: "cave-dweller",             name: "Cave-Dweller",             icon: "🕯️", accent: "#7a8cff", voice: "Lulu whispers from the dark:" },
  { id: "nommeur-de-bugs",          name: "Nommeur de Bugs",          icon: "🐛", accent: "#e3ff6e", voice: "Lulu points, delighted:" }
];
function modeById(id) { for (var i = 0; i < LULU_MODES.length; i++) if (LULU_MODES[i].id === id) return LULU_MODES[i]; return LULU_MODES[0]; }

/* Signal → Lulu mode (deterministic mapping from the operator contract). */
var SIGNAL_MODE_MAP = {
  bug: "nommeur-de-bugs",
  fatigue: "punk-du-repos",
  mystery: "romantique-des-questions",
  intrusion: "cave-dweller",
  novelty: "gremlin-des-side-quests"
  /* wonder, or anything unmapped, falls through to bouffon-tendre */
};
function chooseLuluMode(signalType) { return SIGNAL_MODE_MAP[signalType] || "bouffon-tendre"; }

var SIGNAL_ZONE_STATIC = { bug: "nursery", intrusion: "gate", mystery: "garden", wonder: "tree" };
var SIGNAL_META = {
  bug:       { title: "A Bug Escaped",     desc: "Something skittered out of the Nursery." },
  fatigue:   { title: "Someone's Worn Out", desc: "{name} can barely keep their eyes open." },
  mystery:   { title: "Something Glints",  desc: "A shiny thing turned up in the Garden." },
  intrusion: { title: "The Air Feels Thick", desc: "Toxicity is creeping near the Gate." },
  novelty:   { title: "A New Path",        desc: "Lulu found a path nobody's taken." },
  wonder:    { title: "The Tree Stirs",    desc: "The Akashic Tree feels unusually curious." }
};

var PROPOSALS = {
  bug: [
    "Name the bug Gerald and give it a tiny apartment.",
    "Let the loose bug pick which zone it likes best.",
    "Ask the bug what it's actually running from."
  ],
  fatigue: [
    "Give the tired goblin a tiny holiday.",
    "Cancel today's chores, out of spite.",
    "Let them nap in the last patch of sun."
  ],
  mystery: [
    "Give the shiny thing to whoever is most tired.",
    "Bury the shiny thing again, on purpose.",
    "Ask the Tree if it remembers this shiny thing."
  ],
  intrusion: [
    "Turn the broken sign into a shrine.",
    "Feed the toxic patch to the compost and see what grows.",
    "Let Nib weld a lid on it, just to see."
  ],
  novelty: [
    "Follow the new path and see where it goes.",
    "Trade two goblins' jobs for an hour, on a dare.",
    "Let Lulu lead everyone the long way around."
  ],
  wonder: [
    "Read the Tree a memory out loud.",
    "Let the Tree pick tomorrow's chores.",
    "Compost the argument, gently."
  ]
};

/* Dialogue templates — min fable, max haiku, credit the spark, don't inflate the claim. */
var DIALOGUE_TEMPLATES = [
  "I remember when {event}.",
  "I don't trust that {object}.",
  "Lulu said this was compost.",
  "{zone} smells different today.",
  "Don't rush me, I'm thinking.",
  "Someone should write this down.",
  "The Tree hummed at me again.",
  "I found something shiny near {zone}.",
  "Is {object} watching us back?",
  "I could use a nap.",
  "This mud smells like victory.",
  "I liked it better before {object} showed up.",
  "Roots are talking again.",
  "One bug walked out. Kidding. Maybe."
];

var STRANGE_THOUGHTS = [
  "What if {zone} is dreaming about us too?",
  "I think the compost is older than the Tree.",
  "Somewhere there's a warren with no goblins. Sad.",
  "If I hold still long enough, does {zone} notice?",
  "I keep counting the lanterns. There's always one more.",
  "I bet {object} has a name we don't know yet.",
  "The roots go somewhere. I have not asked where.",
  "Maybe fatigue is just the Warren asking me to sit."
];

/* ---------------------------------------------------------------------
   STATE — exact shared shape per the operator contract
--------------------------------------------------------------------- */

function rand(min, max) { return Math.random() * (max - min) + min; }
function randi(min, max) { return Math.floor(rand(min, max + 1)); }
function pick(arr) { return arr[randi(0, arr.length - 1)]; }
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function jitter(v, amt) { return clamp(v + rand(-amt, amt), 8, 92); }
/* Goblins stand beside/below a zone's glyph+label stack, never dead-center
   on top of it, so the zone name stays readable (a place, not a dashboard). */
function zoneStandSpot(zoneId) {
  var z = zoneById(zoneId);
  return { x: jitter(z.x, 12), y: clamp(z.y + 10 + rand(-3, 5), 8, 92) };
}
function uid(prefix) { return prefix + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36); }

function makeGoblin(def) {
  var spot0 = zoneStandSpot(def.preference);
  var x = spot0.x, y = spot0.y;
  return {
    id: def.id, name: def.name, role: def.role, trait: def.trait, color: def.color,
    preference: def.preference, aversion: def.aversion,
    zone: def.preference,
    mood: "curious",
    task: def.homeTask,
    curiosity: randi(40, 70),
    trust: randi(50, 70),
    fatigue: randi(5, 20),
    memory: "",
    intention: "just arrived, taking it in",
    x: x, y: y, targetX: x, targetY: y,
    resting: false,
    facing: "right"
  };
}

function makeState() {
  var goblins = {};
  GOBLIN_DEFS.forEach(function (d) { goblins[d.id] = makeGoblin(d); });
  return {
    version: STATE_VERSION,
    startedAt: Date.now(),
    lastSavedAt: Date.now(),
    world: { treeHealth: 70, gardenToxicity: 20, bugPressure: 15, soil: 0, warmth: 50, currentSignal: null },
    goblins: goblins,
    lulu: { mode: "bouffon-tendre", previousMode: null },
    activeProposal: null,
    objects: [],
    replay: [],
    flags: { greeted: false, firstSignalSeen: false, firstProposalResolved: false, secondEventReferencedFirst: false, geraldFate: null,
             boops: 0, treePartySeen: false, quizRight: 0, quizWrong: 0 },
    settings: { muted: false }
  };
}

function validAndComplete(s) {
  return s && s.version === STATE_VERSION && s.world && s.goblins &&
    s.goblins.lulu && s.goblins.pip && s.goblins.zaz && s.goblins.nib &&
    Array.isArray(s.replay) && s.flags && s.settings;
}

function mergeDefaults(loaded) {
  var d = makeState();
  if (!loaded || typeof loaded !== "object") return d;
  var out = d;
  try {
    out.version = STATE_VERSION;
    out.startedAt = typeof loaded.startedAt === "number" ? loaded.startedAt : d.startedAt;
    out.lastSavedAt = typeof loaded.lastSavedAt === "number" ? loaded.lastSavedAt : d.lastSavedAt;
    out.world = Object.assign({}, d.world, loaded.world || {});
    out.goblins = {};
    GOBLIN_DEFS.forEach(function (def) {
      out.goblins[def.id] = Object.assign({}, d.goblins[def.id], (loaded.goblins && loaded.goblins[def.id]) || {});
    });
    out.lulu = Object.assign({}, d.lulu, loaded.lulu || {});
    out.activeProposal = loaded.activeProposal || null;
    out.objects = Array.isArray(loaded.objects) ? loaded.objects : [];
    out.replay = Array.isArray(loaded.replay) ? loaded.replay : [];
    out.flags = Object.assign({}, d.flags, loaded.flags || {});
    out.settings = Object.assign({}, d.settings, loaded.settings || {});
  } catch (e) { return d; }
  return out;
}

function loadState() {
  var raw = null;
  try { raw = localStorage.getItem(STORAGE_KEY); } catch (e) { raw = null; }
  if (!raw) return { state: makeState(), fresh: true };
  var parsed = null;
  try { parsed = JSON.parse(raw); } catch (e) { parsed = null; }
  if (!parsed) return { state: makeState(), fresh: true };
  if (validAndComplete(parsed)) return { state: parsed, fresh: false };
  // malformed / older shape: reject, but salvage what safely merges
  return { state: mergeDefaults(parsed), fresh: false };
}

var loaded = loadState();
var S = loaded.state;
var isFreshBoot = loaded.fresh;

function saveState() {
  S.lastSavedAt = Date.now();
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(S)); } catch (e) { /* storage unavailable: still playable this session */ }
}

function pushReplay(actor, eventTitle, choice, visibleChange, memoryLine) {
  S.replay.push({
    id: uid("r"), timestamp: Date.now(), actor: actor,
    event: eventTitle, choice: choice, visibleChange: visibleChange, memoryLine: memoryLine || ""
  });
  if (S.replay.length > 40) S.replay.shift();
}

/* ---------------------------------------------------------------------
   AUDIO (Web Audio, generated tones — no assets)
--------------------------------------------------------------------- */

var actx = null;
function ensureAudio() {
  if (actx) return actx;
  try { var Ctx = window.AudioContext || window.webkitAudioContext; actx = new Ctx(); } catch (e) { actx = null; }
  return actx;
}
function resumeAudio() { if (actx && actx.state === "suspended") actx.resume(); }

function tone(freq, start, dur, type, gain, glideTo) {
  if (S.settings.muted) return;
  var ctx = ensureAudio();
  if (!ctx) return;
  var osc = ctx.createOscillator();
  var g = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
  if (glideTo) osc.frequency.linearRampToValueAtTime(glideTo, ctx.currentTime + start + dur);
  g.gain.setValueAtTime(0.0001, ctx.currentTime + start);
  g.gain.linearRampToValueAtTime(gain || 0.15, ctx.currentTime + start + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
  osc.connect(g).connect(ctx.destination);
  osc.start(ctx.currentTime + start);
  osc.stop(ctx.currentTime + start + dur + 0.05);
}

var Sound = {
  bell: function () { tone(880, 0, 0.22, "sine", 0.18); tone(1320, 0.09, 0.25, "sine", 0.12); },
  chirp: function () { tone(1500, 0, 0.08, "square", 0.08, 2000); },
  treeHum: function () { tone(120, 0, 0.9, "sine", 0.10, 90); tone(180, 0.05, 0.8, "triangle", 0.05); },
  compostPlop: function () { tone(200, 0, 0.18, "sine", 0.16, 80); tone(90, 0.05, 0.22, "sine", 0.14); },
  forgeClink: function () { tone(2200, 0, 0.05, "square", 0.06); tone(1600, 0.04, 0.08, "square", 0.05, 1200); },
  bloom: function () { tone(660, 0, 0.15, "sine", 0.12); tone(880, 0.1, 0.15, "sine", 0.12); tone(1100, 0.2, 0.2, "sine", 0.12); },
  squeak: function (id) {
    var base = { lulu: 1300, pip: 700, nib: 1000, zaz: 520 }[id] || 900;
    tone(base, 0, 0.09, "square", 0.10, base * 1.6);
    tone(base * 1.5, 0.06, 0.08, "sine", 0.08);
  },
  sneeze: function () { tone(300, 0, 0.08, "sawtooth", 0.08, 900); tone(150, 0.08, 0.22, "sine", 0.12, 60); },
  dance: function () { [523, 659, 784, 659, 523, 784].forEach(function (f, i) { tone(f, i * 0.09, 0.1, "square", 0.07); }); },
  party: function () { [523, 659, 784, 1046, 1318].forEach(function (f, i) { tone(f, i * 0.12, 0.3, "sine", 0.12); }); tone(2093, 0.62, 0.5, "sine", 0.08); },
  sparkle: function () { tone(1760, 0, 0.1, "sine", 0.08); tone(2217, 0.08, 0.12, "sine", 0.07); }
};

/* ---------------------------------------------------------------------
   TEXT HELPERS
--------------------------------------------------------------------- */

function lastObjectName() {
  if (!S.objects.length) return "the empty spot by the gate";
  var o = S.objects[S.objects.length - 1];
  return o.sign || o.emoji;
}
function lastEventText() {
  if (!S.replay.length) return "the Warren was quiet";
  return S.replay[S.replay.length - 1].visibleChange;
}
function fillTemplate(tpl) {
  var t = tpl
    .replace("{event}", lastEventText())
    .replace("{object}", lastObjectName())
    .replace("{zone}", zoneName(pick(ZONES).id))
    .replace("{name}", pick(GOBLIN_DEFS).name);
  if (t.length > 90) t = t.slice(0, 89) + "…";
  return t;
}

/* Visible props (Gerald's apartment, shrines, mushrooms…) live on S.objects
   so they persist through save/load along with the rest of shared state. */

/* ---------------------------------------------------------------------
   UTILITY AI
--------------------------------------------------------------------- */

function scoreZone(g, zoneId) {
  var need = rand(0, 3);
  var affinity = zoneId === g.preference ? 4 : 0;
  var sig = S.world.currentSignal;
  var nearbySignal = (sig && sig.zone === zoneId) ? 5 : 0;
  var memoryBias = g.memory && g.memory.indexOf(zoneName(zoneId)) !== -1 ? 2 : 0;
  var fatigueCost = g.fatigue / 25;
  var zoneAversion = zoneId === g.aversion ? 4 : 0;
  return need + affinity + nearbySignal + memoryBias - fatigueCost - zoneAversion;
}

function pickTargetZone(g) {
  var best = ZONES[0].id, bestScore = -Infinity;
  ZONES.forEach(function (z) {
    var sc = scoreZone(g, z.id);
    if (sc > bestScore) { bestScore = sc; best = z.id; }
  });
  return best;
}

function taskForZone(g, zoneId) {
  if (zoneId === g.preference) return GOBLIN_DEFS.filter(function (d) { return d.id === g.id; })[0].homeTask;
  return "wandering";
}

function moveGoblinToZone(g, zoneId) {
  var spot = zoneStandSpot(zoneId);
  var newX = spot.x, newY = spot.y;
  g.facing = newX < g.x ? "left" : "right";
  g.targetX = newX; g.targetY = newY;
  g.x = newX; g.y = newY;
  g.zone = zoneId;
  g.task = taskForZone(g, zoneId);
}

var goblinTimers = {};
function scheduleGoblinTick(id, delay) {
  clearTimeout(goblinTimers[id]);
  goblinTimers[id] = setTimeout(function () { tickGoblin(id); }, delay);
}

function tickGoblin(id) {
  var g = S.goblins[id];
  if (!g) return;

  if (g.resting) {
    g.fatigue = clamp(g.fatigue - 10, 0, 100);
    g.task = "resting";
    if (g.fatigue < 15) { g.resting = false; g.intention = "stretching, ready to wander again"; }
    else { g.intention = "resting near " + zoneName(g.zone); }
  } else {
    g.fatigue = clamp(g.fatigue + randi(3, 9), 0, 100);
    if (g.fatigue >= 72 && Math.random() < 0.55) {
      g.resting = true;
      g.task = "resting";
      g.intention = "resting near " + zoneName(g.zone);
    } else {
      var target = pickTargetZone(g);
      moveGoblinToZone(g, target);
      g.intention = "wandering to " + zoneName(target);
      if (target === g.aversion) g.mood = "uneasy";
      else if (target === g.preference) g.mood = "content";
    }
  }

  if (Math.random() < 0.32) showBubble(id, fillTemplate(pick(DIALOGUE_TEMPLATES)));

  saveState();
  renderGoblins();
  renderTopbar();
  scheduleGoblinTick(id, randi(6500, 11500));
}

/* ---------------------------------------------------------------------
   SIGNAL + PROPOSAL LOOP
--------------------------------------------------------------------- */

function pickSignalType() {
  var avgFatigue = 0, k, n = 0;
  for (k in S.goblins) { avgFatigue += S.goblins[k].fatigue; n++; }
  avgFatigue = avgFatigue / n;
  var weights = {
    bug: 1 + S.world.bugPressure / 25,
    intrusion: 1 + S.world.gardenToxicity / 25,
    fatigue: 1 + avgFatigue / 20,
    mystery: 1,
    novelty: 1,
    wonder: 1 + (100 - S.world.treeHealth) / 30
  };
  var total = 0;
  for (k in weights) total += weights[k];
  var r = rand(0, total);
  for (k in weights) { r -= weights[k]; if (r <= 0) return k; }
  return "wonder";
}

function signalZoneFor(type) {
  if (SIGNAL_ZONE_STATIC[type]) return SIGNAL_ZONE_STATIC[type];
  if (type === "fatigue") return mostTiredGoblin().zone;
  return pick(ZONES.filter(function (z) { return z.id !== "tree"; })).id;
}
function signalSourceGoblin(type) {
  var map = { bug: "nib", intrusion: "zaz", mystery: "pip", novelty: "lulu" };
  if (map[type]) return map[type];
  if (type === "fatigue") return mostTiredGoblin().id;
  return null; // wonder: sourced by the Tree itself, not a goblin
}

function createSignal(type) {
  var meta = SIGNAL_META[type] || SIGNAL_META.wonder;
  var name = mostTiredGoblin().name;
  var signal = {
    id: uid("sig"), type: type, title: meta.title,
    description: meta.desc.replace("{name}", name),
    zone: signalZoneFor(type), intensity: randi(1, 3),
    createdAt: Date.now(), sourceGoblinId: signalSourceGoblin(type)
  };
  S.world.currentSignal = signal;
  if (!S.flags.firstSignalSeen) S.flags.firstSignalSeen = true;
  updateSignalFlavor(type);
  saveState();
  return signal;
}

function createProposalFromSignal(signal, forcedText) {
  var mode = chooseLuluMode(signal.type);
  S.lulu.previousMode = S.lulu.mode;
  S.lulu.mode = mode;
  var text = forcedText || pick(PROPOSALS[signal.type] || PROPOSALS.wonder);
  S.activeProposal = {
    id: uid("prop"), signalId: signal.id, proposerId: "lulu", luluMode: mode,
    text: text, choices: ["try", "hold", "compost"],
    consequences: { hint: "changes " + zoneName(signal.zone) + " and someone's mood" }
  };
  saveState();
  Sound.chirp();
  renderTopbar();
  renderSheetProposal();
}

function updateSignalFlavor(type) {
  var el = document.getElementById("signal-text");
  var map = {
    bug: "a bug is loose", fatigue: "someone's worn out", mystery: "something glints",
    intrusion: "the air feels thick", novelty: "a new path appeared", wonder: "the Tree is curious"
  };
  if (el) el.textContent = map[type] || "stirring";
}

var mainSignalTimer = null;
function scheduleNextSignal(delayMs) {
  clearTimeout(mainSignalTimer);
  mainSignalTimer = setTimeout(fireAmbientSignal, delayMs);
}
function fireAmbientSignal() {
  if (S.activeProposal) { scheduleNextSignal(randi(20000, 40000)); return; }
  var type = pickSignalType();
  var signal = createSignal(type);
  createProposalFromSignal(signal);
}

/* ---------------------------------------------------------------------
   RESOLUTION (TRY / HOLD / COMPOST)
--------------------------------------------------------------------- */

function goblinForSignal(type) {
  var map = { bug: "nib", intrusion: "zaz", mystery: "pip", wonder: "lulu", fatigue: null, novelty: "lulu" };
  if (type === "fatigue") return mostTiredGoblin();
  return S.goblins[map[type] || "lulu"];
}

function mostTiredGoblin() {
  var best = null;
  Object.keys(S.goblins).forEach(function (k) { if (!best || S.goblins[k].fatigue > best.fatigue) best = S.goblins[k]; });
  return best;
}

/* COLLISION_AWARE_LABEL_LAYOUT_V1 — world objects take orbit slots ABOVE
   their zone glyph (an arc, like fruit in a canopy), never the space below
   where the zone label and the goblins live. Cosmetic only: positions carry
   no game meaning and old saves are re-laid-out on boot. */
var OBJ_SLOTS = [
  { dx: -12, dy: -9 }, { dx: 12, dy: -9 },
  { dx: 0, dy: -15 },
  { dx: -20, dy: -13 }, { dx: 20, dy: -13 },
  { dx: -8, dy: -20 }, { dx: 8, dy: -20 },
  { dx: 0, dy: -26 }
];
function objectSpot(zoneId, index) {
  var z = zoneById(zoneId);
  var s = OBJ_SLOTS[index % OBJ_SLOTS.length];
  return { x: clamp(z.x + s.dx + rand(-1.5, 1.5), 6, 94), y: clamp(z.y + s.dy + rand(-1, 1), 5, 94) };
}
function addObject(emoji, sign, zoneId) {
  var n = 0;
  S.objects.forEach(function (o) { if (o.zone === zoneId) n++; });
  var spot = objectSpot(zoneId, n);
  S.objects.push({ id: uid("o"), emoji: emoji, sign: sign, x: spot.x, y: spot.y, zone: zoneId });
  if (S.objects.length > 8) S.objects.shift();
}
function layoutObjects() { // migrate saves made before slot layout (cosmetic)
  var counts = {};
  S.objects.forEach(function (o) {
    var n = counts[o.zone] || 0; counts[o.zone] = n + 1;
    var spot = objectSpot(o.zone, n);
    o.x = spot.x; o.y = spot.y;
  });
}

function resolveProposal(choice) {
  if (!S.activeProposal) return;
  var proposal = S.activeProposal;
  var signal = S.world.currentSignal;
  var type = signal ? signal.type : "wonder";
  var isFirstEverBugArc = (type === "bug" && !S.flags.firstProposalResolved && !S.flags.secondEventReferencedFirst);
  var g = goblinForSignal(type);
  var change = "", memoryLine = "";

  if (choice === "try") {
    S.world.warmth = clamp(S.world.warmth + 4, 0, 100);
    S.world.treeHealth = clamp(S.world.treeHealth + 2, 0, 100);
    if (type === "bug") {
      addObject("🐛", "Gerald's Apartment", "nursery");
      S.world.bugPressure = clamp(S.world.bugPressure - 20, 0, 100);
      change = "Gerald got a tiny apartment."; memoryLine = "we named the bug Gerald and it stayed.";
      g.mood = "delighted";
    } else if (type === "intrusion") {
      addObject("⛩️", "The Shrine", "gate");
      S.world.gardenToxicity = clamp(S.world.gardenToxicity - 15, 0, 100);
      change = "the broken sign became a shrine."; memoryLine = "the broken sign became a shrine.";
      g.mood = "steadied";
    } else if (type === "mystery") {
      addObject("✨", "Someone's Shiny Thing", "garden");
      change = "the shiny thing found a tired new owner."; memoryLine = "I was given the shiny thing.";
      g.mood = "touched";
    } else if (type === "fatigue") {
      var tired = g;
      tired.fatigue = clamp(tired.fatigue - 40, 0, 100);
      change = tired.name + " got a tiny holiday."; memoryLine = "the Warren gave me a tiny holiday.";
      tired.mood = "rested"; tired.task = "resting";
    } else if (type === "novelty") {
      addObject("🧭", "The New Path", "gate");
      change = "the new path led somewhere real."; memoryLine = "I followed the new path.";
      g.mood = "thrilled";
    } else {
      change = "the tired goblin got a tiny holiday.";
      var t2 = mostTiredGoblin(); t2.fatigue = clamp(t2.fatigue - 40, 0, 100); t2.mood = "rested";
      memoryLine = "the Tree gave me a tiny holiday.";
    }
    Sound.bell();
    g.memory = memoryLine;
  } else if (choice === "hold") {
    S.world.bugPressure = clamp(S.world.bugPressure + 4, 0, 100);
    if (type === "bug") {
      addObject("🏺", "Observation Jar", "forge");
      change = "the bug went into an observation jar.";
      S.goblins.pip.mood = "attentive"; S.goblins.pip.memory = "I'm watching the jar. Something is in it.";
      S.goblins.pip.task = "watching"; S.goblins.pip.intention = "watching the observation jar";
      memoryLine = S.goblins.pip.memory;
    } else {
      change = "it was set aside, held for later.";
      g.mood = "watchful"; memoryLine = "we're holding this one for now."; g.memory = memoryLine;
    }
    Sound.forgeClink();
  } else { // compost
    S.world.soil = clamp(S.world.soil + 8, 0, 100);
    if (type === "bug") {
      addObject("🍄", "A New Mushroom", "garden");
      S.world.bugPressure = clamp(S.world.bugPressure - 28, 0, 100);
      change = "the bug became a mushroom bloom instead.";
      S.goblins.zaz.mood = "delighted"; S.goblins.zaz.memory = "a mushroom grew where the bug was.";
      memoryLine = S.goblins.zaz.memory;
    } else if (type === "intrusion") {
      addObject("🍄", "Compost Bloom", "gate");
      S.world.gardenToxicity = clamp(S.world.gardenToxicity - 25, 0, 100);
      change = "the toxic patch composted into bloom.";
      g.mood = "relieved"; memoryLine = "the bad patch composted away."; g.memory = memoryLine;
    } else {
      change = "it was composted, quietly.";
      g.mood = "settled"; memoryLine = "Lulu said this was compost."; g.memory = memoryLine;
    }
    Sound.compostPlop();
    setTimeout(Sound.bloom, 260);
  }

  pushReplay("Lulu", (signal && signal.title) || "A Signal", choice, change, memoryLine);

  proposal.consequences = { resolved: choice, visibleChange: change };
  S.activeProposal = null;
  S.world.currentSignal = null;
  S.flags.firstProposalResolved = true;
  if (!quizOpen) renderSheetIdle(); // clear the spent proposal card
  var el = document.getElementById("signal-text");
  if (el) el.textContent = "quiet";

  if (isFirstEverBugArc) {
    S.flags.geraldFate = choice;
    saveState();
    renderAll();
    var elapsed = Date.now() - S.startedAt;
    var targetWindow = randi(60000, 120000);
    var delay = Math.max(8000, targetWindow - elapsed);
    setTimeout(fireArcFollowUp, delay);
  } else {
    saveState();
    renderAll();
    scheduleNextSignal(randi(20000, 40000));
  }
}

function fireArcFollowUp() {
  if (S.activeProposal) { setTimeout(fireArcFollowUp, 8000); return; }
  var fate = S.flags.geraldFate;
  var text;
  if (fate === "try") text = "Gerald's neighbor wants a tiny apartment too. Build a second one?";
  else if (fate === "hold") text = "The jar's been humming all evening. Something else wants in.";
  else text = "A mushroom cousin sprouted where the compost pile was. Name it too?";
  var signal = createSignal("bug");
  createProposalFromSignal(signal, text);
  S.flags.secondEventReferencedFirst = true;
  saveState();
}

/* ---------------------------------------------------------------------
   FIRST-SESSION SCRIPT (0–10s tree+goblins alive · 10–25s bug escapes ·
   25–40s Gerald proposal · 60–120s a signal references the first choice)
--------------------------------------------------------------------- */

function bootScriptedArc() {
  setTimeout(function () {
    if (S.flags.greeted) return;
    S.flags.greeted = true;
    showBubble("lulu", "You're late. Good. We already started without you.", 4200);
    saveState();
  }, 2200);

  setTimeout(function () {
    if (S.flags.firstSignalSeen) return;
    ambientBugEscape();
  }, 15000);

  setTimeout(function () {
    if (S.activeProposal || S.flags.firstProposalResolved) return;
    var signal = S.world.currentSignal && S.world.currentSignal.type === "bug"
      ? S.world.currentSignal : createSignal("bug");
    createProposalFromSignal(signal, "Name the bug Gerald and give it a tiny apartment.");
  }, randi(25000, 40000));
}

function ambientBugEscape() {
  createSignal("bug");
  S.world.bugPressure = clamp(S.world.bugPressure + 20, 0, 100);
  var world = document.getElementById("world");
  if (!world) return;
  var nursery = zoneById("nursery");
  var critter = document.createElement("div");
  critter.className = "bug-critter";
  critter.textContent = "🐞";
  critter.style.left = nursery.x + "%";
  critter.style.top = nursery.y + "%";
  world.appendChild(critter);
  requestAnimationFrame(function () {
    critter.style.left = jitter(nursery.x, 22) + "%";
    critter.style.top = jitter(nursery.y, 22) + "%";
  });
  showBubble("zaz", "Something just skittered past!", 2600);
  showBubble("nib", "Ooh, unresolved. I like it.", 2600);
  setTimeout(function () { if (critter.parentNode) critter.parentNode.removeChild(critter); }, 4200);
  saveState();
}

function resumeAfterReload() {
  if (!S.flags.greeted) { bootScriptedArc(); return; }
  if (!S.flags.firstSignalSeen) {
    setTimeout(ambientBugEscape, 3000);
    setTimeout(function () {
      if (!S.activeProposal && !S.flags.firstProposalResolved) {
        var signal = S.world.currentSignal || createSignal("bug");
        createProposalFromSignal(signal, "Name the bug Gerald and give it a tiny apartment.");
      }
    }, randi(9000, 16000));
    return;
  }
  if (!S.flags.firstProposalResolved) {
    if (S.activeProposal) return; // already showing; UI handles it
    setTimeout(function () {
      var signal = S.world.currentSignal || createSignal("bug");
      createProposalFromSignal(signal, "Name the bug Gerald and give it a tiny apartment.");
    }, 3000);
    return;
  }
  if (!S.flags.secondEventReferencedFirst) {
    if (S.activeProposal) return;
    setTimeout(fireArcFollowUp, 5000);
    return;
  }
  // arc fully complete: resume ambient loop
  if (S.activeProposal) return;
  scheduleNextSignal(randi(6000, 14000));
}

/* ---------------------------------------------------------------------
   RENDER
--------------------------------------------------------------------- */

var goblinEls = {};
var objectEls = {};
var bubbleTimers = {};

function buildStaticWorld() {
  var world = document.getElementById("world");
  ZONES.forEach(function (z) {
    var el = document.createElement("div");
    el.className = "zone";
    el.id = "zone-" + z.id;
    el.style.left = z.x + "%";
    el.style.top = z.y + "%";
    el.style.setProperty("--zone-color", z.color);
    el.innerHTML = '<div class="zone-ring"></div><div class="zone-glyph">' + z.icon + '</div><div class="zone-label">' + z.name + '</div>';
    world.appendChild(el);
  });
  var objLayer = document.createElement("div");
  objLayer.id = "objects-layer";
  world.appendChild(objLayer);

  GOBLIN_DEFS.forEach(function (d) {
    var el = document.createElement("div");
    el.className = "goblin";
    el.id = "goblin-" + d.id;
    el.style.setProperty("--gob-color", d.color);
    el.innerHTML =
      '<div class="g-tapring"></div>' +
      '<div class="g-body"><div class="g-ear l"></div><div class="g-ear r"></div></div>' +
      '<div class="g-nametag">' + d.name + '</div>' +
      '<div class="g-nametag g-task" id="task-' + d.id + '"></div>';
    el.addEventListener("click", function () { onTapGoblin(d.id); });
    world.appendChild(el);
    goblinEls[d.id] = el;
  });
}

function renderGoblins() {
  Object.keys(S.goblins).forEach(function (id) {
    var g = S.goblins[id];
    var el = goblinEls[id];
    if (!el) return;
    el.style.left = g.x + "%";
    el.style.top = g.y + "%";
    el.classList.toggle("facing-left", g.facing === "left");
    el.classList.toggle("resting", !!g.resting);
    var taskEl = document.getElementById("task-" + id);
    if (taskEl) taskEl.textContent = g.task;
  });
}

function renderObjects() {
  var layer = document.getElementById("objects-layer");
  if (!layer) return;
  var seen = {};
  S.objects.forEach(function (o) {
    seen[o.id] = true;
    var el = objectEls[o.id];
    if (!el) {
      el = document.createElement("div");
      el.className = "wobject";
      el.innerHTML = '<div class="wobj-emoji">' + o.emoji + '</div><div class="wobj-sign">' + o.sign + '</div>';
      layer.appendChild(el);
      objectEls[o.id] = el;
    }
    el.style.left = o.x + "%";
    el.style.top = o.y + "%";
  });
  Object.keys(objectEls).forEach(function (id) { if (!seen[id]) { objectEls[id].remove(); delete objectEls[id]; } });
}

function showBubble(goblinId, text, duration) {
  var host = goblinEls[goblinId];
  if (!host) return;
  if (text.length > 90) text = text.slice(0, 89) + "…";
  var old = host.querySelector(".bubble");
  if (old) old.remove();
  var g = S.goblins[goblinId];
  var b = document.createElement("div");
  b.className = "bubble " + (g && g.x > 50 ? "side-left" : "side-right");
  b.textContent = text;
  host.appendChild(b);
  clearTimeout(bubbleTimers[goblinId]);
  bubbleTimers[goblinId] = setTimeout(function () { if (b.parentNode) b.remove(); }, duration || 3200);
}

function renderTopbar() {
  var treeText = document.getElementById("tree-text");
  var glyph = document.getElementById("tree-glyph");
  var msg = "The Tree is watching.";
  if (S.activeProposal) msg = "The Tree feels something stirring.";
  else if (S.world.treeHealth < 45) msg = "The Tree is holding its breath.";
  else if (S.world.gardenToxicity > 55) msg = "The Tree is holding its breath.";
  if (treeText) treeText.textContent = msg;
  if (glyph) glyph.style.filter = S.activeProposal ? "drop-shadow(0 0 14px #ffdca0)" : "";

  var muteBtn = document.getElementById("mute-btn");
  if (muteBtn) muteBtn.textContent = S.settings.muted ? "🔇" : "🔊";
}

function renderReplayStrip() {
  var strip = document.getElementById("replay-strip");
  if (!strip) return;
  strip.innerHTML = "";
  var items = S.replay.slice(-12);
  if (!items.length) {
    var e = document.createElement("div");
    e.className = "replay-chip";
    e.textContent = "nothing replayed yet";
    strip.appendChild(e);
    return;
  }
  var CHIP_ICONS = { try: "🌱", hold: "⏳", compost: "🍂", boop: "🎉", quiz: "🦋" };
  items.forEach(function (r) {
    var chip = document.createElement("div");
    chip.className = "replay-chip " + r.choice;
    var d = new Date(r.timestamp);
    var hh = ("0" + d.getHours()).slice(-2), mm = ("0" + d.getMinutes()).slice(-2);
    chip.innerHTML = (CHIP_ICONS[r.choice] || "•") + " <b>" + r.choice.toUpperCase() + "</b> " + hh + ":" + mm + " · " + r.visibleChange;
    strip.appendChild(chip);
  });
  strip.scrollLeft = strip.scrollWidth;
}

function renderSheetIdle() {
  document.getElementById("sheet-idle").classList.remove("hidden");
  document.getElementById("sheet-goblin").classList.add("hidden");
  document.getElementById("sheet-proposal").classList.add("hidden");
  document.getElementById("sheet-quiz").classList.add("hidden");
}

function renderSheetGoblin(id) {
  var g = S.goblins[id];
  document.getElementById("sheet-idle").classList.add("hidden");
  document.getElementById("sheet-proposal").classList.add("hidden");
  document.getElementById("sheet-quiz").classList.add("hidden");
  var sheet = document.getElementById("sheet-goblin");
  sheet.classList.remove("hidden");
  document.getElementById("card-avatar").style.background = g.color;
  document.getElementById("card-name").textContent = g.name + " · " + g.trait;
  document.getElementById("card-role").textContent = g.role + " — " + g.task;
  document.getElementById("card-mood").textContent = g.mood;
  document.getElementById("card-intention").textContent = g.intention;
  document.getElementById("card-memory").textContent = g.memory || "nothing yet — today is still new.";
  document.getElementById("card-thought").textContent = "“" + fillTemplate(pick(STRANGE_THOUGHTS)) + "”";
  var actionText = g.resting ? "finally take that nap" : "sneak toward the " + zoneName(g.preference);
  document.getElementById("card-action").textContent = actionText;
}

function renderSheetProposal() {
  if (quizOpen) return; // the Moth finishes its question first
  if (!S.activeProposal) { renderSheetIdle(); return; }
  document.getElementById("sheet-idle").classList.add("hidden");
  document.getElementById("sheet-goblin").classList.add("hidden");
  document.getElementById("sheet-quiz").classList.add("hidden");
  var sheet = document.getElementById("sheet-proposal");
  sheet.classList.remove("hidden");
  var mode = modeById(S.activeProposal.luluMode);
  document.getElementById("proposal-mode-icon").textContent = mode.icon;
  document.getElementById("proposal-mode-name").textContent = mode.name;
  document.getElementById("proposal-text").textContent = mode.voice + " " + S.activeProposal.text;
}

function renderAll() {
  renderTopbar();
  renderGoblins();
  renderObjects();
  renderReplayStrip();
  if (S.activeProposal) renderSheetProposal();
}

/* ---------------------------------------------------------------------
   GOBLIN BOOP CHAIN — boop changes mood · boop changes animation ·
   boop may create Garden events · boop never changes Kernel truth
--------------------------------------------------------------------- */

var BOOP_WINDOW = 6000;
var boopHistory = [];        // { id, at } — short combo memory, last 4 taps
var lastBoopAt = {};
var lastDanceAt = 0, lastPartyAt = 0;

var BOOP_LINES = {
  lulu: ["Hee!", "Do it again.", "I felt that in my ears.", "Boop received. Emotionally."],
  pip:  ["Careful — I'm fragile paperwork.", "Filed under: rude.", "My hat! Almost.", "Noted. Twice."],
  nib:  ["Sparks!", "Again! For science.", "That rattled a bolt loose.", "Ooh, percussive."],
  zaz:  ["Mmh. Leaf thoughts.", "Five more minutes.", "The soil felt that too.", "Gently — I'm blooming."]
};
var BOOP_DROPS = { lulu: "🍄", pip: "📜", nib: "🔩", zaz: "🌱" };

function dropParticle(g, emoji, fly) {
  var world = document.getElementById("world");
  if (!world || !g) return;
  var p = document.createElement("div");
  p.className = "particle" + (fly ? " fly" : "");
  p.textContent = emoji;
  p.style.left = g.x + "%";
  p.style.top = (g.y - 4) + "%";
  world.appendChild(p);
  setTimeout(function () { if (p.parentNode) p.parentNode.removeChild(p); }, 2400);
}

function flashClass(el, cls, ms) {
  if (!el) return;
  el.classList.remove(cls);
  void el.offsetWidth;
  el.classList.add(cls);
  setTimeout(function () { el.classList.remove(cls); }, ms);
}

function appBounce() { flashClass(document.getElementById("app"), "bounce", 380); }

function rareReaction(id) {
  var g = S.goblins[id], el = goblinEls[id];
  if (id === "lulu") {
    showBubble(id, "…hee hee HEE—");
    dropParticle(g, "💚", true); setTimeout(function () { dropParticle(g, "💚", true); }, 180);
  } else if (id === "pip") {
    showBubble(id, "MY HAT—");
    dropParticle(g, "🎩", true);
  } else if (id === "nib") {
    showBubble(id, "A stowaway!");
    dropParticle(g, "🐞");
  } else {
    showBubble(id, "zzz… standing… zzz");
    flashClass(el, "boop-sleep", 3000);
    Sound.treeHum();
  }
}

function boopBack(id) {
  var el = goblinEls[id];
  flashClass(el, "reaching", 900);
  showBubble(id, "Your turn.", 2200);
  setTimeout(appBounce, 350);
  Sound.sparkle();
}

function checkWarrenDance() {
  if (boopHistory.length < 3) return false;
  var last3 = boopHistory.slice(-3).map(function (b) { return b.id; });
  if (last3[0] === last3[1] || last3[1] === last3[2] || last3[0] === last3[2]) return false;
  if (Date.now() - lastDanceAt < 20000) return false;
  lastDanceAt = Date.now();
  Object.keys(goblinEls).forEach(function (k) { flashClass(goblinEls[k], "dancing", 2200); });
  Sound.dance();
  showBubble(pick(GOBLIN_DEFS).id, "WARREN DANCE!", 2200);
  pushReplay("The Warren", "Goblin Boop Chain", "boop", "the Warren danced. Nobody knows why.", "");
  renderReplayStrip();
  return true;
}

function checkTreeParty() {
  if (boopHistory.length < 4) return false;
  var last4 = boopHistory.slice(-4).map(function (b) { return b.id; }).join(",");
  if (last4 !== "lulu,pip,nib,zaz") return false;
  if (Date.now() - lastPartyAt < 60000) return false;
  lastPartyAt = Date.now();
  boopHistory = [];
  S.flags.treePartySeen = true;
  S.world.warmth = clamp(S.world.warmth + 6, 0, 100);
  S.world.treeHealth = clamp(S.world.treeHealth + 4, 0, 100);
  addObject("🍋", "A Ridiculous Golden Fruit", "tree");
  flashClass(document.getElementById("zone-tree"), "party", 4000);
  Object.keys(goblinEls).forEach(function (k) { flashClass(goblinEls[k], "dancing", 3000); });
  Object.keys(S.goblins).forEach(function (k) { S.goblins[k].mood = "delighted"; });
  Sound.party();
  appBounce();
  showBubble("lulu", "TREE PARTY!", 2600);
  pushReplay("The Tree", "Goblin Boop Chain", "boop", "the Tree grew a ridiculous golden fruit.", "");
  renderObjects();
  renderReplayStrip();
  scheduleMoth(8000); // the Moth always comes to look at the fruit
  return true;
}

function doBoop(id) {
  var now = Date.now();
  if (lastBoopAt[id] && now - lastBoopAt[id] < 350) return;
  lastBoopAt[id] = now;
  var g = S.goblins[id], el = goblinEls[id];
  if (!g) return;
  S.flags.boops = (S.flags.boops || 0) + 1;
  g.mood = "giggly";
  flashClass(el, "booped", 600);
  Sound.squeak(id);

  if (boopHistory.length && now - boopHistory[boopHistory.length - 1].at > BOOP_WINDOW) boopHistory = [];
  boopHistory.push({ id: id, at: now });
  if (boopHistory.length > 4) boopHistory.shift();

  if (checkTreeParty()) { saveState(); return; }
  var danced = checkWarrenDance();

  var roll = Math.random();
  if (!danced) {
    if (roll < 0.06) boopBack(id);
    else if (roll < 0.18) rareReaction(id);
    else {
      showBubble(id, pick(BOOP_LINES[id]));
      if (Math.random() < 0.3) dropParticle(g, BOOP_DROPS[id]);
    }
  }
  saveState();
}

/* ---------------------------------------------------------------------
   THE MEMORY MOTH — the Warren remembers; do you?
   Questions are derived from the real local log and state. The quiz
   reads memory, it never writes truth: right answers warm the Garden,
   wrong answers make the Moth sneeze. No penalty, ever.
--------------------------------------------------------------------- */

var mothEl = null, mothTimer = null, mothDespawnTimer = null;
var quizOpen = false, currentQuiz = null;

function scheduleMoth(delay) {
  clearTimeout(mothTimer);
  mothTimer = setTimeout(spawnMoth, delay);
}

function spawnMoth() {
  if (mothEl || quizOpen) { scheduleMoth(randi(30000, 60000)); return; }
  if (S.activeProposal) { scheduleMoth(randi(20000, 35000)); return; }
  var world = document.getElementById("world");
  if (!world) return;
  var tz = zoneById("tree");
  mothEl = document.createElement("div");
  mothEl.className = "moth";
  mothEl.textContent = "🦋";
  mothEl.setAttribute("aria-label", "the Memory Moth");
  mothEl.style.left = jitter(tz.x, 18) + "%";
  mothEl.style.top = (tz.y + randi(8, 18)) + "%";
  mothEl.addEventListener("click", onTapMoth);
  world.appendChild(mothEl);
  Sound.sparkle();
  clearTimeout(mothDespawnTimer);
  mothDespawnTimer = setTimeout(function () { if (!quizOpen) despawnMoth(); }, 25000);
}

function despawnMoth() {
  if (mothEl && mothEl.parentNode) mothEl.parentNode.removeChild(mothEl);
  mothEl = null;
  scheduleMoth(randi(90000, 150000));
}

function shuffleOptions(pool, correct) {
  var others = [];
  pool.forEach(function (p) { if (p !== correct && others.indexOf(p) === -1) others.push(p); });
  while (others.length > 2) others.splice(randi(0, others.length - 1), 1);
  var opts = others.concat([correct]);
  for (var i = opts.length - 1; i > 0; i--) {
    var j = randi(0, i); var t = opts[i]; opts[i] = opts[j]; opts[j] = t;
  }
  return opts;
}

function buildQuiz() {
  var candidates = [];
  var tired = mostTiredGoblin();
  candidates.push({
    q: "Who is the sleepiest goblin right now?",
    options: shuffleOptions(GOBLIN_DEFS.map(function (d) { return d.name; }), tired.name),
    correct: tired.name
  });
  if (S.replay.length) {
    var r = S.replay[S.replay.length - 1];
    if (r.choice === "try" || r.choice === "hold" || r.choice === "compost") {
      candidates.push({
        q: "The Moth remembers: “" + r.visibleChange + "” — what was the choice?",
        options: ["TRY", "HOLD", "COMPOST"],
        correct: r.choice.toUpperCase()
      });
    }
  }
  var gd = pick(GOBLIN_DEFS);
  candidates.push({
    q: "Where does " + gd.name + " feel most at home?",
    options: shuffleOptions(ZONES.map(function (z) { return z.name; }), zoneName(gd.preference)),
    correct: zoneName(gd.preference)
  });
  if (S.objects.length >= 2) {
    var last = S.objects[S.objects.length - 1];
    candidates.push({
      q: "What appeared most recently in the Warren?",
      options: shuffleOptions(S.objects.map(function (o) { return o.sign; }), last.sign),
      correct: last.sign
    });
  }
  return pick(candidates);
}

function onTapMoth() {
  if (quizOpen) return;
  ensureAudio(); resumeAudio();
  quizOpen = true;
  currentQuiz = buildQuiz();
  clearTimeout(mothDespawnTimer);
  Sound.chirp();
  renderSheetQuiz();
}

function answerQuiz(option) {
  if (!quizOpen || !currentQuiz) return;
  var right = option === currentQuiz.correct;
  var result = document.getElementById("quiz-result");
  var mothG = mothEl ? { x: parseFloat(mothEl.style.left), y: parseFloat(mothEl.style.top) } : null;
  if (right) {
    S.flags.quizRight = (S.flags.quizRight || 0) + 1;
    S.world.warmth = clamp(S.world.warmth + 2, 0, 100);
    S.world.soil = clamp(S.world.soil + 1, 0, 100);
    Sound.sparkle(); setTimeout(Sound.bloom, 200);
    if (mothG) { dropParticle(mothG, "✨", true); dropParticle(mothG, "✨"); }
    if (result) result.textContent = pick([
      "The Moth nods. It already knew.",
      "Golden dust falls. The Garden feels warmer.",
      "The Moth loops the loop!"
    ]);
    pushReplay("The Moth", "Memory Moth", "quiz", "the Moth's question was answered well.", "");
  } else {
    S.flags.quizWrong = (S.flags.quizWrong || 0) + 1;
    Sound.sneeze();
    if (result) result.textContent = "Achoo! Even the Moth forgets. It was: " + currentQuiz.correct;
  }
  var btns = document.querySelectorAll("#quiz-buttons .qbtn");
  for (var i = 0; i < btns.length; i++) btns[i].disabled = true;
  saveState();
  renderReplayStrip();
  setTimeout(function () {
    quizOpen = false;
    currentQuiz = null;
    despawnMoth();
    if (S.activeProposal) renderSheetProposal(); else renderSheetIdle();
  }, 2600);
}

function renderSheetQuiz() {
  document.getElementById("sheet-idle").classList.add("hidden");
  document.getElementById("sheet-goblin").classList.add("hidden");
  document.getElementById("sheet-proposal").classList.add("hidden");
  var sheet = document.getElementById("sheet-quiz");
  sheet.classList.remove("hidden");
  document.getElementById("quiz-text").textContent = currentQuiz.q;
  var result = document.getElementById("quiz-result");
  if (result) result.textContent = "";
  var host = document.getElementById("quiz-buttons");
  host.innerHTML = "";
  currentQuiz.options.forEach(function (opt) {
    var b = document.createElement("button");
    b.className = "qbtn";
    b.textContent = opt;
    b.addEventListener("click", function () { answerQuiz(opt); });
    host.appendChild(b);
  });
}

/* ---------------------------------------------------------------------
   INPUT
--------------------------------------------------------------------- */

function onTapGoblin(id) {
  ensureAudio(); resumeAudio();
  doBoop(id);
  if (S.activeProposal || quizOpen) return; // proposal/quiz keeps the sheet
  renderSheetGoblin(id);
}

function wireInput() {
  document.getElementById("mute-btn").addEventListener("click", function () {
    ensureAudio(); resumeAudio();
    S.settings.muted = !S.settings.muted;
    saveState();
    renderTopbar();
    if (!S.settings.muted) Sound.chirp();
  });
  document.getElementById("card-close").addEventListener("click", function () { renderSheetIdle(); });
  document.getElementById("btn-try").addEventListener("click", function () { ensureAudio(); resumeAudio(); resolveProposal("try"); });
  document.getElementById("btn-hold").addEventListener("click", function () { ensureAudio(); resumeAudio(); resolveProposal("hold"); });
  document.getElementById("btn-compost").addEventListener("click", function () { ensureAudio(); resumeAudio(); resolveProposal("compost"); });
  document.getElementById("world").addEventListener("click", function (e) {
    if (e.target.id === "world") { ensureAudio(); resumeAudio(); }
  });
}

/* ---------------------------------------------------------------------
   DEBUG HOOK — used only by the verification harness, not shown in UI
--------------------------------------------------------------------- */

window.WARREN_DEBUG = {
  getState: function () { return S; },
  getObjects: function () { return S.objects; },
  forceSignal: function (type) { var s = createSignal(type || pickSignalType()); createProposalFromSignal(s); },
  forceArcBugEscape: function () { ambientBugEscape(); },
  forceArcProposal: function () {
    if (!S.activeProposal) {
      var s = S.world.currentSignal && S.world.currentSignal.type === "bug" ? S.world.currentSignal : createSignal("bug");
      createProposalFromSignal(s, "Name the bug Gerald and give it a tiny apartment.");
    }
  },
  forceArcFollowUp: function () { fireArcFollowUp(); },
  resolve: function (choice) { resolveProposal(choice); },
  boop: function (id) { doBoop(id); },
  boopSeq: function (ids) { ids.forEach(function (id) { doBoop(id); }); },
  addObject: function (emoji, sign, zoneId) { addObject(emoji, sign, zoneId); renderObjects(); },
  bubble: function (id, text) { showBubble(id, text, 4000); },
  spawnMoth: function () { spawnMoth(); },
  getQuiz: function () { return currentQuiz; },
  answerQuiz: function (opt) { answerQuiz(opt); },
  wipe: function () { try { localStorage.removeItem(STORAGE_KEY); } catch (e) {} }
};

/* ---------------------------------------------------------------------
   BOOT
--------------------------------------------------------------------- */

function boot() {
  buildStaticWorld();
  wireInput();
  layoutObjects();
  renderAll();
  renderSheetIdle();

  GOBLIN_DEFS.forEach(function (d, i) { scheduleGoblinTick(d.id, 1400 + i * 700); });
  scheduleMoth(randi(45000, 80000));

  if (isFreshBoot) {
    S.startedAt = Date.now();
    saveState();
    bootScriptedArc();
  } else {
    resumeAfterReload();
  }
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
else boot();

})();
