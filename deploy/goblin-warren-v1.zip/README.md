# Goblin Warren — iPhone V1

PLAYABLE SANDBOX PROTOTYPE · AUTHORITY: false · CANON: false · SHIP: false
· HOLD_FOR_OPERATOR

A tiny place that notices you. Four goblins live in a small night-garden
world with a glowing Akashic Tree. They move, rest, and talk on their own.
Every 20-40 seconds Lulu (the Detour Specialist) shifts into one of six
moods and proposes one weird thing. You can **TRY IT**, **HOLD IT**, or
**COMPOST IT** — each choice visibly changes the world, a goblin's mood, and
what gets remembered.

## What this is not

This is a standalone, non-canon sandbox. It is **not** the HELEN Kernel, not
the `goblin-warren` repo's V3 Garden, and its `localStorage` save is **not**
a receipt, ledger, or admission of anything. Nothing here is "verified,"
"canonical," or "sovereign" — things are only ever **tried**, **held**,
**composted**, **remembered**, and **replayed**.

## Run it

```bash
cd warren_iphone_v1
python3 -m http.server 8000
# then open http://localhost:8000/ on this machine, or from an iPhone
# on the same Wi-Fi: http://<this-machine's-LAN-IP>:8000/
```

Or just open `index.html` directly in a browser (`file://` works too — the
verification harness runs it that way).

## Files

- `index.html` — page shell, safe-area/viewport meta, PWA manifest link
- `style.css` — night-garden visual language, iPhone-safe layout
- `game.js` — everything: world data, state, utility-AI goblins, the
  signal/proposal/replay loop, Web Audio sound, localStorage persistence
- `manifest.json` — optional add-to-home-screen metadata
- `verify.js` — Playwright witness script (not shipped with the game)

## Save data

Key: `goblin_warren_v1_state`. One JSON object: world stats, four goblins,
Lulu's mode, the active proposal (if any), placed objects, a capped replay
list, and a few first-session flags. Cleared any time via
`WARREN_DEBUG.wipe()` in the browser console, or clearing site data.

## Debug hook

`window.WARREN_DEBUG` exists for the verification harness only (not shown
in the UI): `getState()`, `getObjects()`, `forceSignal(type)`,
`forceArcBugEscape()`, `forceArcProposal()`, `forceArcFollowUp()`,
`resolve(choice)`, `wipe()`.
IA Production · Dream of Conquest — Goblin Warren · © 2026 JM Tassy — sole author
