# Goblin Warren — iPhone V1

PLAYABLE SANDBOX PROTOTYPE · AUTHORITY: false · CANON: false · SHIP: false
· HOLD_FOR_OPERATOR

A tiny place that notices you. Four goblins live in a small night-garden
world with a glowing Akashic Tree. They move, rest, and talk on their own.
Every 20-40 seconds Lulu (the Detour Specialist) shifts into one of six
moods and proposes one weird thing. You can **TRY IT**, **HOLD IT**, or
**COMPOST IT** — each choice visibly changes the world, a goblin's mood, and
what gets remembered.

## What this is not

This is a standalone, non-canon sandbox. It is **not** the HELEN Kernel, not
the `goblin-warren` repo's V3 Garden, and its `localStorage` save is **not**
a receipt, ledger, or admission of anything. Nothing here is "verified,"
"canonical," or "sovereign" — things are only ever **tried**, **held**,
**composted**, **remembered**, and **replayed**.

## Run it

```bash
cd warren_iphone_v1
python3 -m http.server 8000
# then open http://localhost:8000/ on this machine, or from an iPhone
# on the same Wi-Fi: http://<this-machine's-LAN-IP>:8000/
```

Or just open `index.html` directly in a browser (`file://` works too — the
verification harness runs it that way).

## Files

- `index.html` — page shell, safe-area/viewport meta, PWA manifest link
- `style.css` — night-garden visual language, iPhone-safe layout
- `game.js` — everything: world data, state, utility-AI goblins, the
  signal/proposal/replay loop, Web Audio sound, localStorage persistence
- `manifest.json` — optional add-to-home-screen metadata
- `verify.js` — Playwright witness script (not shipped with the game)

## Goblin Boop Chain

Every goblin is tappable. A boop squeaks, wobbles, squints, sometimes drops
a tiny thing, and says one funny line. Rare reactions exist (Pip's hat,
Nib's stowaway, Zaz asleep standing up) — and sometimes a goblin boops back:
"Your turn." Chain taps within 6 seconds: any three different goblins in a
row start a **Warren Dance**; the exact order Lulu → Pip → Nib → Zaz throws
a **Tree Party** and grows A Ridiculous Golden Fruit.
Law: boop changes mood, boop changes animation, boop may create Garden
events — boop never changes Kernel truth.

## The Memory Moth

A golden moth flutters out of the Akashic Tree now and then. Tap it and it
asks one small question **about your own Warren** — who is sleepiest, what
choice you made last, where a goblin feels at home. Every question is
derived from the real local log: the Warren remembers; do you? Right answers
sprinkle golden dust and warm the Garden a little. Wrong answers make the
Moth sneeze. There is no penalty, ever.

## Warren progression (Level 2 — The High Spire)

Playing earns Garden currencies: **Glow Orbs** ✨ (decisions, boops, parties)
and **Magic Sap** 🔮 (composts, Moth answers, crown claims). They buy nothing
sovereign — they open play spaces. At 10 Sap the **High Spire** 🏰 wakes,
**Tink the Tinkerer** moves in (fifth goblin, builds mechanical weird
things), and quests show on the idle sheet. Old saves upgrade in place.

## Raâm, the Loud Mask (Boss Level 1)

A huge orange mask 👹 appears near the Mycelial Gate and shouts doom:
"RAAAM! FEAR THE MASK!" He has no doom — he only has volume. Every boop
makes a goblin giggle and the mask shrink; laughter composts fear. Four
giggles and he's unmasked ("…boo? …boop."), leaving **A Very Polite Mask**
at the Gate. He threatens nothing real, ever.

## The Little Temple ⛩️

A tiny shrine below the map. Tap it and a rotating host (the Cave Voice,
the Moth, A Very Polite Mask, the Tree half asleep) reads the last event
in three layers — GROUND (what the log says), GARDEN (zone-symbol under
the weekday's planetary current), SKY (a cosmic riff; recurrence noted but
never promoted to law). Readings pay nothing and change nothing —
**meaning is free; state is earned.** Footer, always: "a reading, not a
ruling — the Kernel did not stir."

## The False Crown (the boss)

A gaudy crown 👑 squats the High Spire and declares itself important:
"Bow, tiny goblins!" It has no power — it only has claims (📜×5). Each tap
composts one claim (goblins heckle; +1 Sap each). At zero claims it falls
and becomes **A Very Humble Hat** at the Spire. It always dreams of
returning. The boss threatens nothing real; the Kernel never notices it.

## Save data

Key: `goblin_warren_v1_state`. One JSON object: world stats, four goblins,
Lulu's mode, the active proposal (if any), placed objects, a capped replay
list, and a few first-session flags. Cleared any time via
`WARREN_DEBUG.wipe()` in the browser console, or clearing site data.

## Debug hook

`window.WARREN_DEBUG` exists for the verification harness only (not shown
in the UI): `getState()`, `getObjects()`, `forceSignal(type)`,
`forceArcBugEscape()`, `forceArcProposal()`, `forceArcFollowUp()`,
`resolve(choice)`, `boop(id)`, `boopSeq(ids)`, `spawnMoth()`, `getQuiz()`,
`answerQuiz(opt)`, `addObject(e,s,z)`, `bubble(id,t)`, `award(orbs,sap)`,
`spawnCrown()`, `spawnRaam()`, `wipe()`.
IA Production · Dream of Conquest — Goblin Warren · © 2026 JM Tassy — sole author
